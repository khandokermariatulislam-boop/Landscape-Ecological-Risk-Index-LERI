# =========================================================
# BIVARIATE LISA: Landscape Ecological Risk (LERI)
# vs Fractional Vegetation Cover (FVC) – 2014
# =========================================================

# -------------------------------
# 1. LOAD REQUIRED LIBRARIES
# -------------------------------
library(terra)
library(sf)
library(spdep)
library(tmap)

# -------------------------------
# 2. SET WORKING DIRECTORY
# -------------------------------
setwd("F:/LERI/LERI/LERI/LERI-file")

# -------------------------------
# 3. LOAD RASTERS
# -------------------------------
leri <- rast("Final_LERI_2014_2.tif")
fvc  <- rast("FVC_(2014)_clip.tif")

# -------------------------------
# 4. FIX CRS MISMATCH
# -------------------------------
crs(leri)
crs(fvc)

# Reproject FVC to LERI CRS
fvc_proj <- project(fvc, leri)

# Match resolution & extent
fvc <- resample(fvc_proj, leri, method = "bilinear")

# Verify CRS match
stopifnot(crs(leri) == crs(fvc))

# -------------------------------
# 5. STACK RASTERS
# -------------------------------
stk <- c(leri, fvc)
names(stk) <- c("LERI", "FVC")

# -------------------------------
# 6. RASTER → POINTS
# -------------------------------
pts <- as.points(stk, na.rm = TRUE)
pts_sf <- st_as_sf(pts)

# -------------------------------
# 7. SPATIAL WEIGHTS (KNN)
# -------------------------------
coords <- st_coordinates(pts_sf)

knn <- knearneigh(coords, k = 8)
nb  <- knn2nb(knn)

lw <- nb2listw(nb, style = "W", zero.policy = TRUE)

# -------------------------------
# 8. STANDARDIZE VARIABLES
# -------------------------------
pts_sf$LERI_z <- as.numeric(scale(pts_sf$LERI))
pts_sf$FVC_z  <- as.numeric(scale(pts_sf$FVC))

# -------------------------------
# 9. BIVARIATE LOCAL MORAN'S I
# -------------------------------
lag_fvc <- lag.listw(lw, pts_sf$FVC_z, zero.policy = TRUE)
pts_sf$Ii <- pts_sf$LERI_z * lag_fvc

# -------------------------------
# 10. PERMUTATION TEST
# -------------------------------
set.seed(123)
nsim <- 999

Ii_perm <- matrix(NA, nrow = nrow(pts_sf), ncol = nsim)

for (i in 1:nsim) {
  perm_fvc <- sample(pts_sf$FVC_z)
  Ii_perm[, i] <- pts_sf$LERI_z *
    lag.listw(lw, perm_fvc, zero.policy = TRUE)
}

pts_sf$pvalue <- rowMeans(abs(Ii_perm) >= abs(pts_sf$Ii))

# -------------------------------
# 11. CLUSTER CLASSIFICATION
# -------------------------------
pts_sf$cluster <- "Not Significant"
sig <- pts_sf$pvalue <= 0.05

pts_sf$cluster[sig & pts_sf$LERI_z > 0 & lag_fvc > 0] <- "High-High"
pts_sf$cluster[sig & pts_sf$LERI_z > 0 & lag_fvc < 0] <- "High-Low"
pts_sf$cluster[sig & pts_sf$LERI_z < 0 & lag_fvc > 0] <- "Low-High"
pts_sf$cluster[sig & pts_sf$LERI_z < 0 & lag_fvc < 0] <- "Low-Low"

# -------------------------------
# 12. BIVARIATE LISA CLUSTER MAP
# -------------------------------
tmap_mode("plot")

tm_shape(pts_sf) +
  tm_dots(
    col = "cluster",
    palette = c(
      "High-High" = "#B2182B",
      "High-Low"  = "#EF8A62",
      "Low-High"  = "#67A9CF",
      "Low-Low"   = "#2166AC",
      "Not Significant" = "grey80"
    ),
    size = 0.02,
    title = "LISA Cluster Type"
  ) +
  tm_layout(
    title = "Bivariate LISA between LERI and FVC (2014)",
    legend.outside = TRUE,
    frame = FALSE
  )

# -------------------------------
# 13. BIVARIATE MORAN SCATTER PLOT
# -------------------------------
plot(
  pts_sf$LERI_z,
  lag_fvc,
  xlab = "Standardized LERI",
  ylab = "Spatial Lag of FVC",
  main = "Bivariate Moran Scatter Plot (LERI vs FVC, 2014)",
  pch = 20,
  col = "darkblue"
)

abline(h = 0, v = 0, lty = 2)
abline(lm(lag_fvc ~ pts_sf$LERI_z), col = "red", lwd = 2)





  
  
  
  
  
 
  
  

  
  

  
  















               






























